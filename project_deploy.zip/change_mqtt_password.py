import paramiko
import getpass

hostname = "203.194.115.228"
username = "root"

print("=====================================================")
print(" MENGGANTI PASSWORD MQTT TRINGGO ")
print("=====================================================")
password = getpass.getpass(prompt="Masukkan Password ROOT VPS Anda: ")

def ssh_exec(client, command):
    print(f"\n[SERVER] Mengerjakan: {command}")
    stdin, stdout, stderr = client.exec_command(command, get_pty=True)
    out = stdout.read().decode()
    print(out)
    return out

try:
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(hostname, username=username, password=password, disabled_algorithms={'pubkeys': ['rsa-sha2-256', 'rsa-sha2-512']})
    
    # 1. Update Laravel .env
    print("\n[+] Mengubah password MQTT di file .env Laravel...")
    ssh_exec(client, 'sed -i "s/MQTT_PASSWORD=.*/MQTT_PASSWORD=erenvsreiner/g" /var/www/motorcycle_management/.env')
    
    # 2. Update Mosquitto password
    print("\n[+] Memperbarui akun di server Mosquitto...")
    ssh_exec(client, "mosquitto_passwd -b /etc/mosquitto/passwd tringgo_mqtt erenvsreiner")
    ssh_exec(client, "systemctl restart mosquitto")
    
    # 3. Clear laravel cache just in case
    print("\n[+] Membersihkan cache Laravel...")
    ssh_exec(client, "cd /var/www/motorcycle_management && php artisan config:clear")
    
    print("\n=====================================================")
    print(" 🎉 PASSWORD MQTT BERHASIL DIGANTI! 🎉")
    print(" Password baru Anda sekarang: erenvsreiner")
    print("=====================================================")
    
except Exception as e:
    print(f"\n[!] TERJADI KESALAHAN: {str(e)}")
finally:
    client.close()
